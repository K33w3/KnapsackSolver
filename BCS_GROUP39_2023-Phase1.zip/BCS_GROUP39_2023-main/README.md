# Project 1-1 Group 39

## Group Members

- Eskil Gjerde Sviggum
- Octavian Covalciuc
- Alexander Kadri
- Andrei Visoiu
- Jack Bikar 
- Vasileios Rallis
- Patrick Van Maele

Phase 2 can be found in the "Phase2" branch
