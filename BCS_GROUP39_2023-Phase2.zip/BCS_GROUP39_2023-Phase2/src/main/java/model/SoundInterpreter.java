package model;

import java.io.File;
import javax.sound.sampled.*;
import java.io.IOException;

/**
 * The {@code SoundInterpreter} class provides functionality to play and control audio playback.
 * It implements {@link LineListener} to receive notifications about changes in the line's status.
 */
public class SoundInterpreter implements LineListener {
    private SourceDataLine audioLine;
    public boolean isPaused = false;
    private FloatControl volumeControl;

    /**
     * Responds to start events of audio playback.
     *
     * @param event The line event that occurred.
     */
    @Override
    public void update(LineEvent event) {
        if (LineEvent.Type.START == event.getType()) {
            System.out.println("Playback started.");
        }
    }

    /**
     * Plays music from the specified file path.
     *
     * @param path The file path of the audio file to be played.
     * @throws LineUnavailableException If a line cannot be opened because it is unavailable.
     */
    public void playMusic(String path) throws LineUnavailableException {
        try {
            File audioFile = new File(path);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);

            AudioFormat audioFormat = audioStream.getFormat();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
            audioLine = (SourceDataLine) AudioSystem.getLine(info);
            audioLine.addLineListener(this);
            audioLine.open(audioFormat);
            audioLine.start();

            if (audioLine.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                volumeControl = (FloatControl) audioLine.getControl(FloatControl.Type.MASTER_GAIN);
            }

            int bufferSize = 4096;
            byte[] buffer = new byte[bufferSize];
            int bytesRead;

            while ((bytesRead = audioStream.read(buffer, 0, buffer.length)) != -1) {
                if (!isPaused) {
                    audioLine.write(buffer, 0, bytesRead);
                }
            }

            audioLine.drain();
            audioLine.close();
        } catch (UnsupportedAudioFileException | IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Stops the audio playback and releases system resources associated with the audio line.
     */
    public void stop() {
        if (audioLine != null) {
            audioLine.stop();
            audioLine.close();
            isPaused = false;
        }
    }
}
