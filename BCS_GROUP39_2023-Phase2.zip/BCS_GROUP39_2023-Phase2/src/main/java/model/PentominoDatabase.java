package model;
/**
 * @author Department of Data Science and Knowledge Engineering (DKE)
 * @version 2022.0
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class takes care of reading all pentominoes and their permutations from a CSV
 * Information abpout the structure of the CSV file (also included in pentomino.csv.README)
 * Each line in the CSV file defines one permutation of a pentomino.
 * - The first number is the ID for a pentomino, from 0 to 11.
 * - The second number is the index of the permutation (rotation, flip, etc.), between 0 to 7.
 * - The third and forth numbers are the X and Y sizes respectively.
 * - The following X*Y numbers are a matrix showing which positions in the grid are occupied or empty (defined by the shape of the pentomino).
 * <p>
 * This file does not contain a header.
 * The pentominoes should be sorted by ID in increasing order
 * <p>
 * EXAMPLE:
 * <p>
 * 2,1,3,3,1,0,0,1,1,1,0,0,1
 * <p>
 * ID: 2
 * Permutation: 1
 * X: 3 squares
 * Y: 3 squares
 * Shape:
 * X 0 0
 * X X X
 * 0 0 X
 */
public class PentominoDatabase {
	//Stores and loads the data on program initialization
	public static int[][][][] data = loadData("src/main/resources/pentominos.csv");


	/**
	 * Loads and decodes the CSV file containing pentomino shapes and permutations.
	 * Each line in the CSV file defines one permutation of a pentomino.
	 * The format is as follows:
	 * - First number: ID for a pentomino, from 0 to 11.
	 * - Second number: Index of the permutation (rotation, flip, etc.), between 0 to 7.
	 * - Third and fourth numbers: X and Y sizes respectively.
	 * - Following X*Y numbers: A matrix showing which positions in the grid are occupied or empty.
	 *
	 * @param fileName The name of the CSV file to be used.
	 * @return A 4D array representing the list of pentomino pieces. Dimensions: 1-Piece ID; 2-Mutation; 3-X representation; 4-Y representation.
	 * @throws RuntimeException if the file is not found (indicating a wrong file location or typo in the fileName parameter).
	 */
	private static int[][][][] loadData(String filePath) {
		ArrayList<ArrayList<int[][]>> dynamicList = new ArrayList<>();

		File file = new File(filePath);
		if (!file.exists()) {
			throw new RuntimeException("File not found: " + filePath);
		}

		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				String[] values = scanner.nextLine().split(",");

				if (Integer.valueOf(values[0]) > dynamicList.size() - 1) {
					dynamicList.add(new ArrayList<>());
				}

				int xSize = Integer.valueOf(values[2]);
				int ySize = Integer.valueOf(values[3]);
				int[][] piece = new int[xSize][ySize];

				for (int i = 0; i < xSize * ySize; i++) {
					piece[i / ySize][i % ySize] = Integer.valueOf(values[4 + i]);
				}

				dynamicList.get(dynamicList.size() - 1).add(piece);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		}

		int[][][][] staticList = new int[dynamicList.size()][][][];
		for (int i = 0; i < dynamicList.size(); i++) {
			staticList[i] = dynamicList.get(i).toArray(new int[0][0][0]);
		}

		return staticList;
	}

	/**
	 * Main function used for visualizing and debugging the reading of the CSV file with pentomino pieces.
	 * This method is intended for testing and should not be called in the solution search process.
	 *
	 * @param args Command line arguments (not used).
	 */
	public static void main(String[] args) {
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[i].length; j++) {
				System.out.print(i + "," + j + "," + data[i][j].length + "," + data[i][j][0].length);

				for (int k = 0; k < data[i][j].length; k++) {
					for (int l = 0; l < data[i][j][k].length; l++) {
						System.out.print("," + data[i][j][k][l]);
					}
				}

				System.out.println();
			}
		}
	}
}
