package model;

import model.game.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.List;

public class UI extends JPanel implements KeyListener {
	public int[][] upcomingMatrix;
	private final int[][] state;
	private final int cellSize;
	private final Game game;
	private final JFrame frame;

	/**
	 * Constructs the UI for the game.
	 * This constructor initializes the game's user interface, including the game window and its layout.
	 *
	 * @param numRows  The number of rows in the game grid.
	 * @param numCols  The number of columns in the game grid.
	 * @param cellSize The size of each cell in the game grid.
	 * @param game     The game instance associated with this UI.
	 * @param frame    The JFrame to be used for the game's display.
	 */
	public UI(int numRows, int numCols, int cellSize, Game game, JFrame frame) {
		this.cellSize = cellSize;
		this.game = game;
		this.frame = frame;

		frame.setLayout(new BorderLayout());

		frame.setPreferredSize(new Dimension((numCols + 7) * cellSize + 9 * cellSize * 2 / 3, (numRows + 2) * cellSize));
		frame.add(this, BorderLayout.CENTER);

		frame.pack();
		frame.setResizable(false);
		ImageIcon img = new ImageIcon("src/main/java/ui/images/pentomino_logo.png");
		frame.setIconImage(img.getImage());
		frame.getContentPane().setBackground(new Color(34, 34, 34));
		frame.addKeyListener(this);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		state = new int[numRows][numCols];
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				state[i][j] = -1;
			}
		}
	}

	/**
	 * Retrieves the main frame of the game.
	 * This method returns the JFrame used for the game's display.
	 *
	 * @return The JFrame used for the game's display.
	 */
	public JFrame getMainFrame() {
		return frame;
	}

	/**
	 * Closes the game window.
	 * This method disposes of the game's JFrame, effectively closing the game window.
	 */
	public void exitWindow() {
		frame.dispose();
	}

	/**
	 * Retrieves the location of the game frame.
	 * This method returns the current location of the game's JFrame on the screen.
	 *
	 * @return The current location of the game's JFrame.
	 */
	public Point getFrameLocation() {
		return frame.getLocation();
	}

	/**
	 * Sets the current state of the game grid.
	 * This method updates the UI to reflect the current state of the game grid.
	 *
	 * @param newState The new state of the game grid.
	 */
	public void setState(int[][] newState) {
		for (int i = 0; i < newState.length; i++) {
			System.arraycopy(newState[i], 0, state[i], 0, newState[i].length);
		}
		repaint();
	}

	/**
	 * Creates the matrix for upcoming pieces.
	 * This method generates and displays the matrix showing the upcoming pieces in the game.
	 *
	 * @param ids The list of IDs representing upcoming pieces.
	 */
	public void makeUpcomingMatrix(List<Integer> ids) {
		int length = 4;
		int width = 0;

		for (Integer integer : ids) {
			length += PentominoBuilder.database.get(integer)[0].length;
			if (PentominoBuilder.database.get(integer)[0][0].length > width) {
				width = PentominoBuilder.database.get(integer)[0][0].length;
			}
		}

		upcomingMatrix = new int[length][7];
		this.game.initializeField(upcomingMatrix);
		int x = 1;
		for (Integer id : ids) {
			int[][] shape = PentominoBuilder.database.get(id)[0];
			this.game.addPiece(upcomingMatrix, shape, id, x, (7 - PentominoBuilder.database.get(id)[0][0].length) / 2);
			x += shape.length + 1;
		}
	}

	/**
	 * Paints the game components.
	 * This method is responsible for drawing the game grid, pieces, and other UI elements.
	 *
	 * @param g The Graphics object used for drawing.
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		setBackground(new Color(34, 34, 34));

		for (int i = 0; i < state.length; i++) {
			for (int j = 0; j < state[i].length; j++) {
				g2d.setColor(getColorForID(state[i][j]));
				g2d.fill(new Rectangle2D.Double((j + 6) * cellSize + cellSize * 2 / 3, (i + 1) * cellSize, cellSize, cellSize));
				g2d.setColor(getColorForID(state[i][j] + 20));
				g2d.fill(new Rectangle2D.Double((j + 6) * cellSize + cellSize * 2 / 3 + cellSize / 5, (i + 1) * cellSize + cellSize / 5, cellSize - 2 * cellSize / 5, cellSize - 2 * cellSize / 5));
				g2d.setColor(Color.WHITE);
				g2d.draw(new Rectangle2D.Double((j + 6) * cellSize + cellSize * 2 / 3, (i + 1) * cellSize, cellSize, cellSize));
			}
		}

		int upcomingCellSize = cellSize * 2 / 3;

		int xcoord = upcomingCellSize + (state[0].length + 7) * cellSize;
		int ycoord = upcomingCellSize / 2 + cellSize;

		FontMetrics metrics = g2d.getFontMetrics();
		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("", Font.BOLD, cellSize / 2));
		int nextw = metrics.stringWidth("NEXT");
		int pos = xcoord + (7 * upcomingCellSize - nextw) / 2 - nextw / 4;
		g2d.drawString("NEXT", pos, ycoord + upcomingCellSize * 19 / 4);
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(7.0f));
		g2d.draw(new Rectangle2D.Double(xcoord, ycoord + upcomingCellSize * 7 / 2, 7 * upcomingCellSize, 2 * upcomingCellSize));

		for (int i = 0; i < upcomingMatrix.length; i++) {
			for (int j = 0; j < 7; j++) {
				g2d.setColor(getColorForID(upcomingMatrix[i][j]));
				if (getColorForID(upcomingMatrix[i][j]) == Color.BLACK) {
					g2d.setColor(Color.DARK_GRAY);
				}
				g2d.fill(new Rectangle2D.Double((j + 1) * upcomingCellSize + (state[0].length + 7) * cellSize, (i + 6) * upcomingCellSize + cellSize, upcomingCellSize, upcomingCellSize));
				g2d.setColor(getColorForID(upcomingMatrix[i][j] + 20));
				if (getColorForID(upcomingMatrix[i][j] + 20) == Color.BLACK) {
					g2d.setColor(Color.DARK_GRAY);
				}
				g2d.fill(new Rectangle2D.Double((j + 1) * upcomingCellSize + upcomingCellSize / 5 + (state[0].length + 7) * cellSize, (i + 6) * upcomingCellSize + upcomingCellSize / 5 + cellSize, upcomingCellSize - 2 * upcomingCellSize / 5, upcomingCellSize - 2 * upcomingCellSize / 5));
			}
		}
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(7.0f));
		g2d.draw(new Rectangle2D.Double(upcomingCellSize + (state[0].length + 7) * cellSize, 6 * upcomingCellSize + cellSize, 7 * upcomingCellSize, upcomingMatrix.length * upcomingCellSize));


		int rectangleWidth = 7 * upcomingCellSize;
		int rectangleHeight = 2 * upcomingCellSize;

		g2d.setColor(Color.DARK_GRAY);
		g2d.fill(new Rectangle2D.Double(xcoord, ycoord, rectangleWidth, rectangleHeight));
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(7.0f));
		g2d.draw(new Rectangle2D.Double(xcoord, ycoord, rectangleWidth, rectangleHeight));

		g2d.setFont(new Font("", Font.BOLD, cellSize / 2));
		FontMetrics fontMetrics = g2d.getFontMetrics();
		String scoreText = "Score: " + this.game.score;
		int textWidth = fontMetrics.stringWidth(scoreText);
		int centerX = xcoord + (rectangleWidth - textWidth) / 2;
		g2d.setColor(Color.WHITE);
		g2d.drawString(scoreText, centerX, ycoord + upcomingCellSize * 4 / 3);

		xcoord = upcomingCellSize * 5 / 3;
		ycoord = 5 * cellSize;
		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("", Font.BOLD, cellSize * 10 / 21));
		g2d.drawString("HIGHEST SCORES", xcoord, ycoord - upcomingCellSize / 5);
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(7.0f));
		g2d.draw(new Rectangle2D.Double(upcomingCellSize, ycoord - cellSize, 5 * cellSize, upcomingCellSize * 2 / 3 + cellSize));

		xcoord = upcomingCellSize;
		ycoord = 5 * cellSize + upcomingCellSize * 2 / 3;
		g2d.setColor(Color.DARK_GRAY);
		g2d.fill(new Rectangle2D.Double(xcoord, ycoord, 5 * cellSize, 6 * cellSize));
		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("", Font.BOLD, cellSize * 3 / 8));
		g2d.drawString("Trained Bot (Rnd.): " + this.game.highestScore, xcoord + upcomingCellSize / 2, ycoord + upcomingCellSize * 3 / 2);
		g2d.drawString("Trained Bot (Sort): \u221E", xcoord + upcomingCellSize / 2, ycoord + 2 * upcomingCellSize * 3 / 2);
		g2d.drawString("Player: " + Game.playerHighScore, xcoord + upcomingCellSize / 2, ycoord + 3 * upcomingCellSize * 3 / 2);
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(7.0f));
		g2d.draw(new Rectangle2D.Double(xcoord, ycoord, 5 * cellSize, 6 * cellSize));

		if (!this.game.gameOver && Game.playMode == Game.PlayMode.SinglePlayer) {
			for (int i = 0; i < this.game.activeShape.length; i++) {
				for (int j = 0; j < this.game.activeShape[0].length; j++) {
					if (this.game.activeShape[i][j] != 0) {
						int x = getMaxX();
						if (x < 0) x = 0;
						if (state[i + x][j + game.actualY] != -1) {
							g2d.setColor(Color.WHITE);
							g2d.setStroke(new BasicStroke(1.0f));
						} else {
							g2d.setColor(getColorForID(game.actualID));
							g2d.setStroke(new BasicStroke(3.0f));
						}
						g2d.draw(new Rectangle2D.Double((j + 6 + game.actualY) * cellSize + cellSize * 2 / 3, (i + 1 + x) * cellSize, cellSize, cellSize));
					}
				}
			}
		}
	}

  /**
   * Gets the maximum X-coordinate where the current piece can be placed.
   * This method calculates the lowest possible position for the current piece on the game grid.
   *
   * @return The maximum X-coordinate for the current piece.
   */
	private int getMaxX() {
		int[][] cop = new int[game.VERTICAL_GRID_SIZE][game.HORIZONTAL_GRID_SIZE];
		for (int i = 0; i < game.VERTICAL_GRID_SIZE; i++) {
			cop[i] = Arrays.copyOf(state[i], state[i].length);
		}

		game.removePiece(cop, game.activeShape, game.actualX, game.actualY);

		int x = 0;
		while (game.canPlace(cop, game.activeShape, x, game.actualY)) {
			if (x + 1 > game.VERTICAL_GRID_SIZE - game.activeShape.length) {
				x++;
				break;
			}
			x++;
		}
		if (x == 1) return 0;
		return x - 1;
	}

  /**
   * Gets the color associated with a specific piece ID.
   * This method returns the color used to represent a piece with the given ID.
   *
   * @param id The ID of the piece.
   * @return The color associated with the given piece ID.
   */
	private Color getColorForID(int id) {
		if (id == 0) {
			return new Color(0, 121, 241);      // Tetris Blue
		} else if (id == 1) {
			return new Color(255, 165, 0); // Tetris Orange
		} else if (id == 2) {
			return new Color(0, 255, 255); // Tetris Cyan
		} else if (id == 3) {
			return new Color(0, 255, 0);   // Tetris Green
		} else if (id == 4) {
			return new Color(255, 0, 255); // Tetris Magenta
		} else if (id == 5) {
			return new Color(255, 100, 193); // Light Pink
		} else if (id == 6) {
			return new Color(255, 0, 0);   // Tetris Red
		} else if (id == 7) {
			return new Color(255, 255, 0); // Tetris Yellow
		} else if (id == 8) {
			return new Color(192, 192, 192);  // Light gray instead of black
		} else if (id == 9) {
			return new Color(0, 0, 128);      // Navy instead of dark blue
		} else if (id == 10) {
			return new Color(128, 0, 0);     // Maroon instead of dark red
		} else if (id == 11) {
			return new Color(0, 128, 0);     // Dark green instead of dark green
		} else if (id == 20) {
			return new Color(173, 216, 230); // Light blue instead of light black
		} else if (id == 21) {
			return new Color(255, 215, 0);   // Gold instead of light orange
		} else if (id == 22) {
			return new Color(144, 238, 144); // Light green instead of light cyan
		} else if (id == 23) {
			return new Color(50, 205, 50);   // Lime green instead of light green
		} else if (id == 24) {
			return new Color(255, 182, 193); // Pink instead of light pink
		} else if (id == 25) {
			return new Color(255, 182, 193); // Pink instead of light pink
		} else if (id == 26) {
			return new Color(255, 69, 0);    // Red-Orange instead of light red
		} else if (id == 27) {
			return new Color(255, 255, 192); // Light yellow instead of light yellow
		} else if (id == 28) {
			return new Color(169, 169, 169); // Dark gray instead of dark gray
		} else if (id == 29) {
			return new Color(0, 0, 205);     // Medium blue instead of dark blue
		} else if (id == 30) {
			return new Color(205, 0, 0);     // Red instead of dark red
		} else if (id == 31) {
			return new Color(0, 205, 0);     // Green instead of dark green
		} else {
			return Color.BLACK;
		}
	}

  /**
   * Handles key typed events during the game.
   * This method responds to key typed events, such as moving the piece down.
   *
   * @param e The KeyEvent associated with the key typed.
   */
	@Override
	public void keyTyped(KeyEvent e) {
		if (Game.playMode == Game.PlayMode.SinglePlayer) {
			switch (e.getKeyChar()) {
				case 's':
					game.moveDown();
					break;
			}
		}
	}

  /**
   * Handles key pressed events during the game.
   * This method responds to key pressed events, such as pausing the game or moving the piece quickly down.
   *
   * @param e The KeyEvent associated with the key pressed.
   */
	@Override
	public void keyPressed(KeyEvent e) {
		if (Game.playMode == Game.PlayMode.SinglePlayer || Game.playMode == Game.PlayMode.TrainTheBot || Game.playMode == Game.PlayMode.TrainedBot || Game.playMode == Game.PlayMode.RBBot) {
			switch (e.getKeyChar()) {
				case ' ':
					if (this.game.gameTimer.isRunning()) {
						game.moveFastDown();
					}
					break;
				case 'p':
					game.pauseGame();
					break;
				case 'o':
					game.resumeGame();
					break;
			}
		}
	}

  /**
   * Handles key released events during the game.
   * This method responds to key released events, such as moving the piece left, right, or rotating it.
   *
   * @param e The KeyEvent associated with the key released.
   */
	@Override
	public void keyReleased(KeyEvent e) {
		if (Game.playMode == Game.PlayMode.SinglePlayer && this.game.gameTimer.isRunning()) {
			switch (e.getKeyChar()) {
				case 'a' -> game.moveLeft();
				case 'd' -> game.moveRight();
				case 'r' -> game.rotateShape();
			}
		}
	}
}
