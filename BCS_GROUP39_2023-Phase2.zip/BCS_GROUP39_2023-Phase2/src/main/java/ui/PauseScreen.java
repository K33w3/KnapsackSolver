package ui;

import model.game.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * A class representing a pause screen for the game.
 */
public class PauseScreen {

	private JDialog dialog;

    /**
     * Constructs a PauseScreen dialog.
     *
     * @param parentFrame The parent JFrame to which this dialog is associated.
     * @param gameClass   The instance of the Game class to control the game's state.
     */
	public PauseScreen(JFrame parentFrame, Game gameClass) {
		// transparency check
		if (!GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
				.isWindowTranslucencySupported(GraphicsDevice.WindowTranslucency.TRANSLUCENT)) {
			System.err.println("Transparency not supported in this environment");
			return;
		}

		// dialog initialization
		dialog = new JDialog();
		dialog.setUndecorated(true);
		dialog.setSize(300, 400);
		dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		dialog.setResizable(false);
		dialog.setOpacity(0.9f); // Transparency

		// creating container
		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.setOpaque(false);
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Optional padding

		// game paused title creation
		JLabel titleLabel = new JLabel("<html><div style='text-align: center;'><br/>Game Paused");
		titleLabel.setOpaque(false);
		titleLabel.setHorizontalAlignment(JLabel.CENTER);
		titleLabel.setFont(new Font("Arial", Font.BOLD, 50));
		mainPanel.add(titleLabel, BorderLayout.NORTH);

		// creating the close button
		ImageIcon backArrowIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/left-arrow-circle-solid-60.png");
		JButton backArrowButton = new JButton(backArrowIcon);
		backArrowButton.setBorder(BorderFactory.createEmptyBorder());
		backArrowButton.setContentAreaFilled(false);
		backArrowButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("returning to main menu");
				dialog.dispose();
				gameClass.exitGamePrematurely();
				System.out.println("going back to main menu");
				openMainMenu();

				//need a way to communicate with main menu
			}
		});

		// jpanel for the close button to create some padding so it is not on the edges
		JPanel buttonPanel = new JPanel(new BorderLayout());
		buttonPanel.add(backArrowButton, BorderLayout.CENTER);
		buttonPanel.setOpaque(false);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // padding on the sides of the button
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);

		// keylister for "o" for game resume
		mainPanel.setFocusable(true);
		mainPanel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyChar() == 'O' || e.getKeyChar() == 'o') {
					System.out.println("O key pressed: resuming game");
					dialog.dispose();
					gameClass.resumeGame();

				}
			}
		});

		// adding mainPanel to the dialog
		dialog.setContentPane(mainPanel);

		dialog.pack();
        // Center on screen if parentFrame is null
        dialog.setLocationRelativeTo(parentFrame);
	}

    /**
     * Displays the pause screen dialog.
     * This method makes the dialog visible and requests focus for key event handling.
     */
	public void display() {
		dialog.setVisible(true);
		dialog.getContentPane().requestFocusInWindow(); //requesting focus on window so keyListener can work
	}

    /**
     * Opens the main menu.
     * This method is used to navigate back to the main menu from the pause screen.
     */
	private void openMainMenu() {
		MainMenu MainMenu = new MainMenu();
	}
}
