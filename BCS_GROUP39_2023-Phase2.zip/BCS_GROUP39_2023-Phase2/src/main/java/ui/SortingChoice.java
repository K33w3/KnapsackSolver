package ui;

import model.game.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A class representing a sorting choice dialog for the game.
 */
public class SortingChoice {

    private JDialog dialog;
    private JRadioButton r1;
    private JRadioButton r2;

    /**
     * Constructs a SortingChoice dialog.
     *
     * @param parentFrame The parent JFrame to which this dialog is associated.
     */
    public SortingChoice(JFrame parentFrame) {
        // title label setup
        JLabel titleLabel = new JLabel("<html><div style='text-align: center;'>" +
                "Sorting Method Selection");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 35));
        // radio button setup
        r1 = new JRadioButton("Sorted");
        r2 = new JRadioButton("Random");

        // grouping the radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(r1);
        group.add(r2);

        // check and exit button setup
        ImageIcon checkIcon = new ImageIcon("src/main/java/ui/images/sorting_choice/check-square-solid-60.png");
        ImageIcon exitIcon = new ImageIcon("src/main/java/ui/images/sorting_choice/x-circle-solid-60.png");

        JButton checkButton = new JButton(checkIcon);
        JButton exitButton = new JButton(exitIcon);

        checkButton.setBorder(BorderFactory.createEmptyBorder());
        checkButton.setContentAreaFilled(false);

        exitButton.setBorder(BorderFactory.createEmptyBorder());
        exitButton.setContentAreaFilled(false);

        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCheckButtonClick();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

        // dialog setup
        dialog = new JDialog(parentFrame, "Sorting Method Selection", true);
        dialog.setUndecorated(true);
        dialog.setSize(300, 200);
        dialog.setTitle("Sorting Method Selection");
        ImageIcon img = new ImageIcon("src/main/java/ui/images/pentomino_logo.png");
        dialog.setIconImage(img.getImage());
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel radioPanel = new JPanel();
        radioPanel.add(r1);
        radioPanel.add(r2);
        radioPanel.setOpaque(true);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(checkButton);
        buttonPanel.add(exitButton);
        buttonPanel.setOpaque(true);

        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; 
        gbc.gridwidth = GridBagConstraints.REMAINDER; 
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        
        gbc.gridy = 0; // first row
        containerPanel.add(titleLabel, gbc);

        gbc.gridy = 1; // second row
        containerPanel.add(radioPanel, gbc);

        gbc.gridy = 2; // third row
        containerPanel.add(buttonPanel, gbc);

        // adding containerPanel to dialog
        dialog.setContentPane(containerPanel);

        dialog.pack();
        dialog.setLocationRelativeTo(parentFrame);

        dialog.pack();
        dialog.setLocationRelativeTo(parentFrame);
    }
    /**
     * Handles the event when the check button is clicked.
     * This method determines the selected sorting method (sorted or random)
     * and initializes the game accordingly.
     */
    private void handleCheckButtonClick() {
        if (r1.isSelected()) {
            System.out.println("Sorted selected");
            Game.sorted = true;
        } else if (r2.isSelected()) {
            System.out.println("Random selected");
            Game.sorted = false;
        }
        if (BotOptionsScreen.trained) {
            Game.initialiseGame(3);
            System.out.println("TRAINED");
        } else {
            Game.initialiseGame(2);
            System.out.println("DUMB");
        }
        dialog.dispose();
    }

    /**
     * Displays the sorting choice dialog.
     * This method makes the dialog visible.
     */
    public void display() {
        dialog.setVisible(true);
    }
}
