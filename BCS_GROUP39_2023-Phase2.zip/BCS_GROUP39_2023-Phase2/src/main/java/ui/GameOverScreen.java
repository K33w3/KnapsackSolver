package ui;

import model.game.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Represents the game over screen in the game.
 * This screen is displayed when the game ends and shows the player's score.
 * It provides options to replay the game, exit, or return to the main menu.
 */
public class GameOverScreen extends JFrame {

	/**
	 * Constructs a GameOverScreen with the given score.
	 *
	 * @param score The final score achieved in the game.
	 */
	public GameOverScreen(final int score) {

		final ImageIcon playIcon = new ImageIcon("src/main/java/ui/images/game_over_screen/refresh-regular-60_white.png");
		final ImageIcon exitIcon = new ImageIcon("src/main/java/ui/images/game_over_screen/exit-solid-60_white.png");
		final ImageIcon backArrowIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/left-arrow-circle-solid-60_white.png");

		final JButton playButton = new JButton(playIcon);
		final JButton exitButton = new JButton(exitIcon);
		final JButton backArrowButton = new JButton(backArrowIcon);

		final JLabel scoreLabel = new JLabel("Score: " + score);
		scoreLabel.setFont(new Font("Arial", Font.BOLD, 40));
		scoreLabel.setForeground(Color.WHITE); // Set text color
		scoreLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 45, 0));

		playButton.setBorder(BorderFactory.createEmptyBorder());
		playButton.setContentAreaFilled(false);

		exitButton.setBorder(BorderFactory.createEmptyBorder());
		exitButton.setContentAreaFilled(false);

		backArrowButton.setBorder(BorderFactory.createEmptyBorder());
		backArrowButton.setContentAreaFilled(false);

		final JLabel emptyLabel = new JLabel("");

		final PaintBackground backgroundPanel = new PaintBackground("src/main/java/ui/images/game_over_screen/tetris_dark_game_over_revision4.png");
		this.setContentPane(backgroundPanel);

		// Adding ActionListener to buttons
		playButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent e) {
				// Code to execute when play button is clicked
				System.out.println("replay button clicked!");
				System.out.println("play button clicked");
				Game.initialiseGame(1);
				GameOverScreen.this.dispose();
			}
		});

		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent e) {
				// exits if exit button is clicked
				System.out.println("Exit button clicked!");
				System.exit(0);
			}
		});

		backArrowButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent e) {
				System.out.println("going back to main menu");
				openMainMenu();

			}
		});

		// Layout setup
		setLayout(new GridBagLayout());
		final GridBagConstraints gbc = new GridBagConstraints();

		// needs to be removed
		final JLabel gameOverLabel = new JLabel(""); // is not being used
		gameOverLabel.setHorizontalAlignment(JLabel.CENTER); // not being used

		// Score Label
		gbc.gridy = 0;
		gbc.weighty = 0;
		gbc.gridx = 0;
		gbc.gridwidth = 3;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.CENTER;
		add(scoreLabel, gbc);

		gbc.weightx = 1;// width between icons
		gbc.gridwidth = 1;
		gbc.gridy = 1;
		add(playButton, gbc);
		gbc.gridx = 1; // Second column
		add(exitButton, gbc);

		// Spacer
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 3;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.ipady = 20; // increase the internal padding
		add(emptyLabel, gbc);
		gbc.ipady = 0; // reset ipady

		// Back Button
		gbc.gridx = 0; // start from the first column
		gbc.gridy = 4;
		gbc.gridwidth = 3; // span across all columns
		gbc.fill = GridBagConstraints.NONE; // do not stretch horizontally
		gbc.anchor = GridBagConstraints.CENTER; // center alignment

		add(backArrowButton, gbc);

		// Window Properties
		final ImageIcon img = new ImageIcon("src/main/java/ui/images/pentomino_logo.png");
		setIconImage(img.getImage());
		gameOverLabel.setFont(new Font("Arial", Font.BOLD, 30));
		setTitle("Game Over");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		pack();
		//setLocationRelativeTo(null); // Center on screen
		setSize(720, 680);
		setVisible(true);
	}

	/**
	 * Opens the main menu screen and disposes of the current game over screen.
	 */
	private void openMainMenu() {
		final Point location = this.getLocation();
		final MainMenu MainMenu = new MainMenu();
		MainMenu.setLocation(location);
		this.dispose();
	}
}