package ui;

import model.game.Game;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * Represents the main menu screen for the game.
 */
public class MainMenu extends JFrame {

  private final int numCols = 5;
  private final int cellSize = 40;
  private final int numRows = 15;

  /**
   * Constructs the main menu screen with buttons for playing the game, accessing bot options, and exiting the game.
   */
  public MainMenu() {
    ImageIcon playIcon = new ImageIcon(
        "src/main/java/ui/images/main_menu/play-regular-60_white.png");
    ImageIcon exitIcon = new ImageIcon(
        "src/main/java/ui/images/main_menu/exit-solid-60_white.png");
    ImageIcon botIcon = new ImageIcon(
        "src/main/java/ui/images/main_menu/bot-solid-60_white.png");
    ImageIcon helpIcon = new ImageIcon("src/main/java/ui/images/help_menu/info-circle-solid-60_white.png");

    JButton playButton = new JButton(playIcon);
    JButton exitButton = new JButton(exitIcon);
    JButton botButton = new JButton(botIcon);
    JButton helpButton = new JButton(helpIcon);

    playButton.setBorder(BorderFactory.createEmptyBorder());
    playButton.setContentAreaFilled(false);

    exitButton.setBorder(BorderFactory.createEmptyBorder());
    exitButton.setContentAreaFilled(false);

    botButton.setBorder(BorderFactory.createEmptyBorder());
    botButton.setContentAreaFilled(false);

    helpButton.setBorder(BorderFactory.createEmptyBorder());
    helpButton.setContentAreaFilled(false);

    PaintBackground backgroundPanel = new PaintBackground(
        "src/main/java/ui/images/main_menu/tetris_dark_main_menu_revision5.png");
    this.setContentPane(backgroundPanel);
    
    // Adding ActionListener to buttons
    playButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            System.out.println("play button clicked");
            Game.initialiseGame(1);
            MainMenu.this.dispose();
          }
        });
      //exit button
    exitButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // exits if exit button is clicked
            System.out.println("exit button clicked");
            System.exit(0);
          }
        });

    botButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            System.out.println("opening bot options JFrame");
            openBotOptionsScreen();
          }
        });

    helpButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        System.out.println("opening info menu");
        openHelpMenu();
      }
    });

    // Layout setup
    setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.weightx = 1; // width between buttons
    add(playButton, gbc); // first column
    gbc.gridx = 1;
    add(botButton, gbc); // second column
    gbc.gridx = 2;
    add(exitButton, gbc); // third column
    // GridBag constraints for the new icon
    gbc.gridx = 1; // second column (the center)
    gbc.gridy = 2; // second row
    gbc.gridwidth = 1; // width
    gbc.anchor = GridBagConstraints.CENTER; // centering icon
    gbc.insets = new Insets(25, 0, 0, 0); // a way of leaving space between rows
    add(helpButton, gbc);

    // Window Properties

    ImageIcon img = new ImageIcon("src/main/java/ui/images/pentomino_logo.png");
    setIconImage(img.getImage());
    setTitle("Pentris Main Menu");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
    pack();
    setLocationRelativeTo(null); // Center on screen
    setSize((numCols + 7) * cellSize + 9 * cellSize * 2 / 3, (numRows + 2) * cellSize);
    setVisible(true);
  }

  /**
   * Opens the bot options screen.
   * This method disposes of the current main menu frame and opens a new frame for bot options.
   */
  private void openBotOptionsScreen() {
    Point location = this.getLocation();
    BotOptionsScreen botOptionsScreen = new BotOptionsScreen();
    ImageIcon img = new ImageIcon("src/main/java/ui/images/pentomino_logo.png");
    botOptionsScreen.setIconImage(img.getImage());
    botOptionsScreen.setLocation(location);
    botOptionsScreen.setSize(720, 680);
    botOptionsScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    botOptionsScreen.setResizable(false);
    this.dispose();
  }

  /**
   * Opens the help menu.
   * This method creates and displays a help menu window, positioning it relative to the main menu window.
   */
  private void openHelpMenu() {
    HelpMenu help = new HelpMenu(this);
    // centering window
    Point mainWindowLocation = this.getLocation();
    Dimension mainWindowSize = this.getSize();
    int x = mainWindowLocation.x + (mainWindowSize.width - help.getWidth()) / 2;
    int y = mainWindowLocation.y + (mainWindowSize.height - help.getHeight()) / 2;
    help.setLocation(x, y);
    help.setVisible(true);
  }
}
