package ui;

import model.game.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Represents the bot options screen in the game.
 * This screen allows players to choose between different bot modes or train their own bot.
 */
public class BotOptionsScreen extends JFrame {

    public static boolean trained = false;

    /**
     * Constructs a BotOptionsScreen.
     * This screen provides options to select a dumb bot, a trained bot, train a new bot, or return to the main menu.
     */
    public BotOptionsScreen() {
        // icon setup
        ImageIcon dumbBotIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/dizzy-solid-60_white.png");
        ImageIcon trainedBotIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/cloud-lightning-solid-60_white.png");
        ImageIcon trainYourBotIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/edit-alt-solid-60_white.png");
        ImageIcon backArrowIcon = new ImageIcon("src/main/java/ui/images/bot_options_menu/left-arrow-circle-solid-60_white.png");

        // button setup
        JButton dumbBotButton = new JButton(dumbBotIcon);
        JButton trainedBotButton = new JButton(trainedBotIcon);
        JButton trainYourBotButton = new JButton(trainYourBotIcon);
        JButton backArrowButton = new JButton(backArrowIcon);

        // set button borders to be invisble
        dumbBotButton.setBorder(BorderFactory.createEmptyBorder());
        dumbBotButton.setContentAreaFilled(false);

        trainedBotButton.setBorder(BorderFactory.createEmptyBorder());
        trainedBotButton.setContentAreaFilled(false);

        trainYourBotButton.setBorder(BorderFactory.createEmptyBorder());
        trainYourBotButton.setContentAreaFilled(false);

        backArrowButton.setBorder(BorderFactory.createEmptyBorder());
        backArrowButton.setContentAreaFilled(false);

        // create labels
        JLabel dumbBotLabel = new JLabel("Dumb Bot");
        JLabel trainedBotLabel = new JLabel("Trained Bot");
        JLabel trainYourBotLabel = new JLabel("Train your Bot");
        JLabel backLabel = new JLabel("Go Back To Main Menu");
        JLabel emptyLabel = new JLabel("");
        dumbBotLabel.setForeground(Color.WHITE);
        trainYourBotLabel.setForeground(Color.WHITE);
        backLabel.setForeground(Color.WHITE);
        trainedBotLabel.setForeground(Color.WHITE);
        this.getContentPane().add(dumbBotLabel);

        PaintBackground backgroundPanel = new PaintBackground(
                "src/main/java/ui/images/bot_options_menu/tetris_dark_main_menu_revision5.png");
        this.setContentPane(backgroundPanel);

        // layout setup
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // common settings for layout
        gbc.weightx = 1;
        // adding labels in the first row
        gbc.anchor = GridBagConstraints.CENTER; // center alignment
        gbc.gridy = 0; // first row

        gbc.gridx = 0; // first column
        add(dumbBotLabel, gbc);

        gbc.gridx = 1; // second column
        add(trainedBotLabel, gbc);

        gbc.gridx = 2; // third column
        add(trainYourBotLabel, gbc);

        // adding buttons in the second row
        gbc.fill = GridBagConstraints.HORIZONTAL; // allow horizontal stretch
        gbc.gridy = 1; // second row

        gbc.gridx = 0; // first column
        add(dumbBotButton, gbc);

        gbc.gridx = 1; // second column
        add(trainedBotButton, gbc);

        gbc.gridx = 2; // third column
        add(trainYourBotButton, gbc);

        // Spacer
        gbc = new GridBagConstraints(); // resetting gbc
        gbc.gridx = 0;
        gbc.gridy = 2; // third row
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipady = 25;
        add(emptyLabel, gbc);

        // Back Label
        gbc = new GridBagConstraints(); // resetting gbc
        gbc.gridx = 0;
        gbc.gridy = 3; // fourth row
        gbc.gridwidth = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        add(backLabel, gbc);

        // Back Button
        gbc = new GridBagConstraints(); // resetting gbc
        gbc.gridx = 0;
        gbc.gridy = 4; // fifth row
        gbc.gridwidth = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        add(backArrowButton, gbc);

        // action listeners
        dumbBotButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("run dumb bot button");
                callSortingSelection();
                exitWindow();
            }
        });

        trainedBotButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("run trained bot");
                trained = true;
                callSortingSelection();
                exitWindow();
            }
        });

        trainYourBotButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("train your bot activated");
                // int input pop up
                String input = JOptionPane.showInputDialog(BotOptionsScreen.this, "Enter an integer:");
                // int test (we might need to switch it to double values)
                try {
                    int number = Integer.parseInt(input);
                    JOptionPane.showMessageDialog(BotOptionsScreen.this, "You entered: " + number);
                    Game.repetitions = number;
                    Game.initialiseGame(4);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(BotOptionsScreen.this,
                            "Invalid input. Please enter an integer.");
                }

            }
        });

        backArrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("going back to main menu");
                openMainMenu();

            }
        });
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Bot Options Screen");
        this.setVisible(true);

    }

    /**
     * Opens the main menu screen and disposes of the current bot options screen.
     */
    private void openMainMenu() {
        Point location = this.getLocation();
        MainMenu MainMenu = new MainMenu();
        MainMenu.setLocation(location);
        this.dispose();
    }

    /**
     * Displays the sorting choice dialog.
     */
    private void callSortingSelection() {
        SortingChoice sort = new SortingChoice(this); // 'this' refers to the parent JFrame
        sort.display();
    }

    /**
     * Closes the bot options screen.
     */
    public void exitWindow() {
        this.dispose();
      }
}
