package ui;

import javax.swing.*;
import java.awt.*;

/**
 * A custom JPanel class for painting a background image.
 */
class PaintBackground extends JPanel {
    private final Image backgroundImage;

    /**
     * Constructs a PaintBackground panel with a specified background image.
     *
     * @param filePath The file path of the image to be set as the background.
     */
    public PaintBackground(String filePath) {
        backgroundImage = new ImageIcon(filePath).getImage();
    }

    /**
     * Paints the background of the panel with the specified image.
     * This method is overridden from the JPanel class.
     *
     * @param g The Graphics object used for painting.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the background image
        g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
    }
}
