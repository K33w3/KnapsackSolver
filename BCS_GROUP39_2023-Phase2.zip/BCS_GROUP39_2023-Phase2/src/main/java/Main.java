import javax.swing.SwingUtilities;
import ui.MainMenu;

public class Main {

  public static void main(String[] args) {
    SwingUtilities.invokeLater(MainMenu::new);
  }
}
