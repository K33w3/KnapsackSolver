## How to compile the game
# Group 39

---

Run ./src/main/java/Main.java

While compiling make sure all packages are imported in the compiler.